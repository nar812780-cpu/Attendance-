import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Settings, ChevronLeft } from "lucide-react";
import { BarChart, Bar, ResponsiveContainer } from "recharts";

const weekdays = ["S", "M", "T", "W", "T", "F", "S"];

const monthsData = [
  { monthNumber: 1, monthName: "January", daysCount: 31, startOffset: 4, holidays: [1, 19], launchDay: [], quarter: "Q1" },
  { monthNumber: 2, monthName: "February", daysCount: 28, startOffset: 0, holidays: [14, 16], launchDay: [], quarter: "Q1" },
  { monthNumber: 3, monthName: "March", daysCount: 31, startOffset: 0, holidays: [17], launchDay: [], quarter: "Q1" },
  { monthNumber: 4, monthName: "April", daysCount: 30, startOffset: 3, holidays: [], launchDay: [], quarter: "Q2" },
  { monthNumber: 5, monthName: "May", daysCount: 31, startOffset: 5, holidays: [10, 25], launchDay: [], quarter: "Q2" },
  { monthNumber: 6, monthName: "June", daysCount: 30, startOffset: 1, holidays: [19, 21], launchDay: [], quarter: "Q2" },
  { monthNumber: 7, monthName: "July", daysCount: 31, startOffset: 3, holidays: [4], launchDay: [], quarter: "Q3" },
  { monthNumber: 8, monthName: "August", daysCount: 31, startOffset: 6, holidays: [], launchDay: [], quarter: "Q3" },
  { monthNumber: 9, monthName: "September", daysCount: 30, startOffset: 2, holidays: [7], launchDay: [], quarter: "Q3" },
  { monthNumber: 10, monthName: "October", daysCount: 31, startOffset: 4, holidays: [12, 31], launchDay: [], quarter: "Q4" },
  { monthNumber: 11, monthName: "November", daysCount: 30, startOffset: 0, holidays: [11, 26], launchDay: [], quarter: "Q4" },
  { monthNumber: 12, monthName: "December", daysCount: 31, startOffset: 2, holidays: [25], launchDay: [], quarter: "Q4" },
];

const chartData = [
  { name: "M", val: 40 },
  { name: "T", val: 55 },
  { name: "W", val: 45 },
  { name: "T", val: 70 },
  { name: "F", val: 60 },
];

function AttendanceMiniChart({ onClick }: { onClick?: () => void }) {
  return (
    <motion.div 
      whileHover={onClick ? { scale: 1.1 } : {}}
      whileTap={onClick ? { scale: 0.9 } : {}}
      onClick={onClick}
      className={`h-10 w-7 opacity-80 ${onClick ? 'cursor-pointer' : 'pointer-events-none'}`}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData}>
          <Bar dataKey="val" fill="#2563eb" radius={[1, 1, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}

function StatsPage({ 
  vacationDays, 
  halfVacationDays = {},
  absentDays,
  overtimeDays = {},
  overtimeHours = {}
}: { 
  vacationDays: Record<number, number[]>;
  halfVacationDays?: Record<number, number[]>;
  absentDays: Record<number, number[]>;
  overtimeDays?: Record<number, number[]>;
  overtimeHours?: Record<number, Record<number, number>>;
}) {
  const totalPresentDays = Object.keys(vacationDays).reduce((acc, monthStr) => {
    const month = parseInt(monthStr);
    const days = vacationDays[month] || [];
    const hDays = halfVacationDays[month] || [];
    const monthTotal = days.reduce((sum, d) => sum + (hDays.includes(d) ? 0.5 : 1), 0);
    return acc + monthTotal;
  }, 0);
  const totalAbsentDays = (Object.values(absentDays) as number[][]).reduce((acc, days) => acc + days.length, 0);
  const totalOvertimeDays = (Object.values(overtimeDays) as number[][]).reduce((acc, days) => acc + days.length, 0);
  const totalOvertimeHours = Object.values(overtimeHours).reduce((acc, monthObj) => {
    return acc + Object.values(monthObj).reduce((sum, h) => sum + h, 0);
  }, 0);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-4xl bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-slate-200 overflow-y-auto max-h-[80vh]"
    >
      <div className="flex justify-between items-start mb-10 pb-6 border-b border-slate-100">
        <div>
          <h2 className="text-4xl font-black font-serif italic text-slate-900 leading-tight">Analytics</h2>
          <p className="font-mono text-[10px] uppercase tracking-widest text-slate-400 mt-2">Attendance & Vacation Summary</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-emerald-50 p-8 rounded-3xl border border-emerald-100/50">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-emerald-600 mb-6">Total Present Days</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-7xl font-black text-emerald-500 font-serif italic leading-none">{totalPresentDays}</span>
            <span className="text-xl font-serif italic text-emerald-300 font-bold font-semibold">days</span>
          </div>
        </div>
        <div className="bg-red-50 p-8 rounded-3xl border border-red-100/50">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-red-500 mb-6 font-bold">Total Absent Days</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-7xl font-black text-red-500 font-serif italic leading-none">{totalAbsentDays}</span>
            <span className="text-xl font-serif italic text-red-300 font-bold font-semibold">days</span>
          </div>
        </div>
        <div className="bg-orange-50 p-8 rounded-3xl border border-orange-100/50">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-orange-600 mb-6">Total Overtime Days</h3>
          <div className="flex flex-col gap-1">
            <div className="flex items-baseline gap-2">
              <span className="text-7xl font-black text-orange-500 font-serif italic leading-none">{totalOvertimeDays}</span>
              <span className="text-xl font-serif italic text-orange-300 font-bold font-semibold">days</span>
            </div>
            {totalOvertimeHours > 0 && (
              <span className="text-xs font-mono font-bold text-orange-600/85">
                ({totalOvertimeHours} hrs total)
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}



interface MonthCalendarProps {
  monthNumber: number;
  monthName: string;
  daysCount: number;
  startOffset: number;
  holidays?: number[];
  launchDay?: number[];
  today?: number;
  quarter?: string;
  isDetailed?: boolean;
  isVacationMode?: boolean;
  isAbsentMode?: boolean;
  isOvertimeMode?: boolean;
  isHolidayMode?: boolean;
  onToggleVacationMode?: () => void;
  onToggleAbsentMode?: () => void;
  onToggleOvertimeMode?: () => void;
  onToggleHolidayMode?: () => void;
  onDateClick?: (day: number) => void;
  selectedDays?: number[];
  halfDays?: number[];
  absentDays?: number[];
  overtimeDays?: number[];
  monthOvertimeHours?: Record<number, number>;
  weeklyOffDays?: number[];
}

function MonthCalendar({ 
  monthNumber, 
  monthName, 
  daysCount, 
  startOffset, 
  holidays = [], 
  launchDay = [], 
  today, 
  quarter = "Q1",
  isDetailed = false,
  isVacationMode = false,
  isAbsentMode = false,
  isOvertimeMode = false,
  isHolidayMode = false,
  onToggleVacationMode,
  onToggleAbsentMode,
  onToggleOvertimeMode,
  onToggleHolidayMode,
  onDateClick,
  selectedDays = [],
  halfDays = [],
  absentDays = [],
  overtimeDays = [],
  monthOvertimeHours = {},
  weeklyOffDays = []
}: MonthCalendarProps) {
  const days = Array.from({ length: daysCount }, (_, i) => i + 1);
  const blanks = Array.from({ length: startOffset }, (_, i) => i);
  // Fixed to exactly 6 rows (42 total grid cells) for perfect layout consistency
  const totalCells = 42;
  const fillBlanks = totalCells - days.length - startOffset;

  const weekdays = ["S", "M", "T", "W", "T", "F", "S"];

  const cellHeightClass = isDetailed 
    ? 'h-14 sm:h-20' 
    : 'h-10 sm:h-8';

  return (
    <div className={`flex flex-col bg-white overflow-hidden border border-slate-300 shadow-md rounded-sm w-full shrink h-fit self-start font-sans transition-all duration-300 ${isDetailed ? 'max-w-3xl' : 'max-w-[340px] hover:scale-[1.02] cursor-pointer'}`}>
      <div className={`p-2 border-b border-slate-300 bg-slate-50 flex justify-between items-center ${isDetailed ? 'py-4 px-6' : ''}`}>
        <span className={`font-serif italic font-black text-slate-900 ${isDetailed ? 'text-2xl' : 'text-sm'}`}>{monthNumber}/2026</span>
        <span className={`font-mono text-slate-800 font-bold uppercase tracking-widest ${isDetailed ? 'text-lg' : 'text-[10px]'}`}>{monthName}</span>
      </div>
      
      {/* Grid Header */}
      <div className="grid grid-cols-7 border-b border-slate-300 bg-slate-100">
        {weekdays.map((day, idx) => {
          const isOffColumn = weeklyOffDays.includes(idx);
          return (
            <div 
              key={`${day}-${idx}`} 
              className={`p-1 text-center border-r last:border-r-0 border-slate-200 font-bold tracking-widest uppercase text-slate-700 ${isOffColumn ? 'bg-slate-200 text-slate-900' : ''} ${isDetailed ? 'py-3 text-sm' : 'text-[10px] sm:text-[7px]'}`}
            >
              {day}
            </div>
          );
        })}
      </div>

      {/* Calendar Body */}
      <div className="grid grid-cols-7 flex-1 bg-white">
        {/* Empty cells */}
        {blanks.map((i) => {
          const dayOfWeek = i % 7;
          const isOffColumn = weeklyOffDays.includes(dayOfWeek);
          return (
            <div 
              key={`blank-${i}`} 
              className={`border-r border-b border-slate-200 ${isOffColumn ? 'bg-slate-100' : 'bg-slate-50/20'} ${cellHeightClass}`} 
            />
          );
        })}
        
        {/* Days */}
        {days.map((day) => {
          const isLaunch = launchDay.includes(day);
          const isToday = today === day;
          const isSelected = selectedDays.includes(day);
          const isHalfPresent = halfDays.includes(day);
          const isAbsent = absentDays.includes(day);
          const isOvertime = overtimeDays.includes(day);
          const dayOfWeek = (startOffset + day - 1) % 7;
          const isWeeklyOff = weeklyOffDays.includes(dayOfWeek);
          const isHoliday = holidays.includes(day);
          const isSplit = isSelected && isOvertime;
          
          return (
            <div 
              key={day} 
              onClick={(e) => {
                if (isDetailed && onDateClick) {
                  e.stopPropagation();
                  onDateClick(day);
                }
              }}
              className={`border-r border-b border-slate-200 relative group transition-colors flex flex-col items-center justify-center select-none ${cellHeightClass} ${
                isLaunch 
                  ? 'bg-slate-900 text-white' 
                  : isHoliday 
                    ? 'ring-[3px] ring-inset ring-red-500 bg-red-50/20 hover:bg-red-50/40' 
                    : isSplit 
                      ? 'text-white' 
                      : isSelected 
                        ? (isHalfPresent ? 'text-slate-950 font-bold' : 'bg-blue-600 text-white') 
                        : isAbsent 
                          ? 'bg-red-600 text-white' 
                          : isOvertime 
                            ? 'bg-purple-600 text-white font-semibold' 
                            : isWeeklyOff 
                              ? 'bg-slate-100 hover:bg-slate-200/50' 
                              : 'hover:bg-slate-100'
              } ${isWeeklyOff && (isSelected || isAbsent || isOvertime || isSplit) ? 'ring-2 ring-inset ring-red-500/60' : ''} ${(isVacationMode || isAbsentMode || isOvertimeMode || isHolidayMode) && isDetailed ? 'cursor-cell' : ''}`}
              style={isSplit && !isLaunch && !isHoliday ? { background: 'linear-gradient(135deg, #2563eb 50%, #9333ea 50%)' } : (isHalfPresent && !isLaunch && !isHoliday) ? { background: 'linear-gradient(135deg, #2563eb 50%, transparent 50%)' } : undefined}
            >
              <span className={`font-serif italic leading-none ${
                (isLaunch || (isSelected && !isHalfPresent && !isHoliday) || isAbsent || isOvertime) 
                  ? (isWeeklyOff ? 'text-red-200 font-extrabold' : 'text-white') 
                  : isHoliday 
                    ? 'text-red-600 font-black' 
                    : isWeeklyOff 
                      ? 'text-red-600 font-bold' 
                      : 'text-black font-medium'
              } ${isDetailed ? 'text-xl sm:text-2xl' : 'text-sm sm:text-xs'}`}>
                {day}
              </span>
              
              {isDetailed && !isOvertime && (
                <div className="mt-2 text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  {monthName.slice(0,3)} {day}
                </div>
              )}

              {isDetailed && isOvertime && monthOvertimeHours[day] !== undefined && (
                <div className="mt-1 px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-purple-700 border border-purple-500 text-purple-100 uppercase tracking-wider">
                  {monthOvertimeHours[day]} hrs
                </div>
              )}

              {isLaunch && (
                <div className="absolute bottom-0 w-full h-[2px] bg-slate-900/10" />
              )}
            </div>
          );
        })}

        {/* Empty ending cells */}
        {Array.from({ length: fillBlanks }).map((_, i) => {
          const dayOfWeek = (startOffset + daysCount + i) % 7;
          const isOffColumn = weeklyOffDays.includes(dayOfWeek);
          return (
            <div 
              key={`fill-${i}`} 
              className={`border-r border-b border-slate-200 ${isOffColumn ? 'bg-slate-100' : 'bg-slate-50/20'} ${cellHeightClass}`} 
            />
          );
        })}
      </div>

      {isDetailed && (
        <div className="p-3 border-t border-slate-200 bg-slate-50/30 flex justify-start gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleVacationMode}
            className={`px-2.5 py-1.5 text-white text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-2 border transition-all duration-200 cursor-pointer select-none ${
              isVacationMode 
                ? 'bg-blue-600 border-blue-500 hover:bg-blue-700 hover:border-blue-600 shadow-md ring-2 ring-blue-300' 
                : 'bg-emerald-500 border-emerald-400 hover:bg-emerald-600 hover:border-emerald-500 shadow-emerald-500/20'
            }`}
            id="vacation-month-button"
          >
            Present
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleAbsentMode}
            className={`px-2.5 py-1.5 text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-2 border transition-all duration-200 cursor-pointer select-none ${
              isAbsentMode 
                ? 'bg-red-600 border-red-500 text-white hover:bg-red-700 hover:border-red-600 shadow-md ring-2 ring-red-300' 
                : 'bg-yellow-400 border-yellow-300 text-yellow-950 hover:bg-yellow-500 hover:border-yellow-400 shadow-yellow-500/10'
            }`}
            id="vacation-month-button-duplicate"
          >
            Absent
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleOvertimeMode}
            className={`px-2.5 py-1.5 text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-2 border transition-all duration-200 cursor-pointer select-none ${
              isOvertimeMode 
                ? 'bg-purple-600 border-purple-500 text-white hover:bg-purple-700 hover:border-purple-600 shadow-md ring-2 ring-purple-300' 
                : 'bg-pink-500 border-pink-400 text-white hover:bg-pink-600 hover:border-pink-500 shadow-pink-500/10'
            }`}
            id={`vacation-month-button-duplicate-overtime-${monthNumber}`}
          >
            Overtime
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleHolidayMode}
            className={`px-2.5 py-1.5 text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-2 border transition-all duration-200 cursor-pointer select-none ${
              isHolidayMode 
                ? 'bg-red-600 border-red-500 text-white hover:bg-red-700 hover:border-red-600 shadow-md ring-2 ring-red-300' 
                : 'bg-red-500 border-red-400 text-white hover:bg-red-600 hover:border-red-500 shadow-red-500/10'
            }`}
            id={`vacation-month-button-duplicate-holiday-${monthNumber}`}
          >
            Holiday
          </motion.button>
        </div>
      )}
    </div>
  );
}

const getMonthlyHolidays = (monthNumber: number, holidaysList: number[], weeklyOffDays: number[]) => {
  const monthObj = monthsData.find(m => m.monthNumber === monthNumber);
  if (!monthObj) return [];
  const { daysCount, startOffset } = monthObj;
  const list: number[] = [];
  for (let day = 1; day <= daysCount; day++) {
    const dayOfWeek = (startOffset + day - 1) % 7;
    const isWeeklyOff = weeklyOffDays.includes(dayOfWeek);
    if (holidaysList.includes(day) || isWeeklyOff) {
      list.push(day);
    }
  }
  return list;
};

function MonthStatsPage({
  monthNumber,
  monthName,
  vacationDays,
  halfVacationDays = {},
  absentDays,
  overtimeDays = {},
  overtimeHours = {},
  holidayDays,
  weeklyOffDays
}: {
  monthNumber: number;
  monthName: string;
  vacationDays: Record<number, number[]>;
  halfVacationDays?: Record<number, number[]>;
  absentDays: Record<number, number[]>;
  overtimeDays?: Record<number, number[]>;
  overtimeHours?: Record<number, Record<number, number>>;
  holidayDays: Record<number, number[]>;
  weeklyOffDays: number[];
}) {
  const pDays = vacationDays[monthNumber] || [];
  const hDays = halfVacationDays[monthNumber] || [];
  const presentCount = pDays.reduce((sum, d) => sum + (hDays.includes(d) ? 0.5 : 1), 0);
  
  const absentCount = (absentDays[monthNumber] || []).length;
  const overtimeCount = (overtimeDays[monthNumber] || []).length;
  const monthOvertimeHoursObj = overtimeHours[monthNumber] || {};
  const overtimeHoursCount = Object.values(monthOvertimeHoursObj).reduce((sum, h) => sum + h, 0);

  const monthSpecificHolidays = holidayDays[monthNumber] || [];
  const holidaysCount = monthSpecificHolidays.length;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-4xl bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-slate-200 overflow-y-auto max-h-[80vh]"
    >
      <div className="flex justify-between items-start mb-8 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-4xl font-black font-serif italic text-slate-900 leading-tight">{monthName} Analytics</h2>
          <p className="font-mono text-[10px] uppercase tracking-widest text-slate-400 mt-2">Attendance Summary for {monthName} 2026</p>
        </div>
      </div>
      
      {/* 4 Metrics: Present, Absent, Overtime, Holiday */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {/* Present Card */}
        <div className="bg-emerald-50/70 p-5 rounded-2xl border border-emerald-100/50 flex flex-col justify-between">
          <h3 className="text-[10px] font-mono uppercase tracking-[0.1em] text-emerald-605 mb-2 font-bold">Present</h3>
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-black text-emerald-500 font-serif italic leading-none">{presentCount}</span>
            <span className="text-xs font-serif italic text-emerald-400 font-bold">days</span>
          </div>
        </div>

        {/* Absent Card */}
        <div className="bg-red-50/70 p-5 rounded-2xl border border-red-100/50 flex flex-col justify-between">
          <h3 className="text-[10px] font-mono uppercase tracking-[0.1em] text-red-500 mb-2 font-bold">Absent</h3>
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-black text-red-500 font-serif italic leading-none">{absentCount}</span>
            <span className="text-xs font-serif italic text-red-400 font-bold">days</span>
          </div>
        </div>

        {/* Overtime Card */}
        <div className="bg-purple-50/70 p-5 rounded-2xl border border-purple-100/50 flex flex-col justify-between">
          <h3 className="text-[10px] font-mono uppercase tracking-[0.1em] text-purple-600 mb-2 font-bold font-semibold">Overtime</h3>
          <div className="flex flex-col gap-0.5">
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-black text-purple-500 font-serif italic leading-none">{overtimeCount}</span>
              <span className="text-xs font-serif italic text-purple-400 font-bold">days</span>
            </div>
            {overtimeHoursCount > 0 && (
              <span className="text-[10px] font-mono font-bold text-purple-600/80">
                ({overtimeHoursCount}h total)
              </span>
            )}
          </div>
        </div>

        {/* Holiday Card */}
        <div className="bg-sky-50/70 p-5 rounded-2xl border border-sky-100/50 flex flex-col justify-between">
          <h3 className="text-[10px] font-mono uppercase tracking-[0.1em] text-sky-600 mb-2 font-bold">Holidays</h3>
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-black text-sky-500 font-serif italic leading-none">{holidaysCount}</span>
            <span className="text-xs font-serif italic text-sky-400 font-bold">days</span>
          </div>
        </div>
      </div>


    </motion.div>
  );
}

export default function App() {
  const [selectedMonth, setSelectedMonth] = useState<number | null>(null);
  const [showStats, setShowStats] = useState(false);
  const [showMonthStats, setShowMonthStats] = useState(false);
  const [isVacationMode, setIsVacationMode] = useState(false);
  const [isAbsentMode, setIsAbsentMode] = useState(false);
  const [isOvertimeMode, setIsOvertimeMode] = useState(false);
  const [isHolidayMode, setIsHolidayMode] = useState(false);
  const [vacationDays, setVacationDays] = useState<Record<number, number[]>>(() => {
    const saved = localStorage.getItem('vacationDays');
    return saved ? JSON.parse(saved) : {};
  });
  const [halfVacationDays, setHalfVacationDays] = useState<Record<number, number[]>>(() => {
    const saved = localStorage.getItem('halfVacationDays');
    return saved ? JSON.parse(saved) : {};
  });
  const [absentDays, setAbsentDays] = useState<Record<number, number[]>>(() => {
    const saved = localStorage.getItem('absentDays');
    return saved ? JSON.parse(saved) : {};
  });
  const [overtimeDays, setOvertimeDays] = useState<Record<number, number[]>>(() => {
    const saved = localStorage.getItem('overtimeDays');
    return saved ? JSON.parse(saved) : {};
  });
  const [overtimeHours, setOvertimeHours] = useState<Record<number, Record<number, number>>>(() => {
    const saved = localStorage.getItem('overtimeHours');
    return saved ? JSON.parse(saved) : {};
  });
  const [holidayDays, setHolidayDays] = useState<Record<number, number[]>>(() => {
    const saved = localStorage.getItem('holidayDays');
    if (saved) return JSON.parse(saved);
    const initial: Record<number, number[]> = {};
    monthsData.forEach(m => {
      if (m.holidays && m.holidays.length > 0) {
        initial[m.monthNumber] = m.holidays;
      }
    });
    return initial;
  });
  const [overtimeModalData, setOvertimeModalData] = useState<{ month: number; day: number } | null>(null);
  const [overtimeInputValue, setOvertimeInputValue] = useState<string>("1");
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [weeklyOffDays, setWeeklyOffDays] = useState<number[]>(() => {
    const saved = localStorage.getItem('weeklyOffDays');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('weeklyOffDays', JSON.stringify(weeklyOffDays));
  }, [weeklyOffDays]);

  useEffect(() => {
    localStorage.setItem('vacationDays', JSON.stringify(vacationDays));
  }, [vacationDays]);

  useEffect(() => {
    localStorage.setItem('halfVacationDays', JSON.stringify(halfVacationDays));
  }, [halfVacationDays]);

  useEffect(() => {
    localStorage.setItem('absentDays', JSON.stringify(absentDays));
  }, [absentDays]);

  useEffect(() => {
    localStorage.setItem('overtimeDays', JSON.stringify(overtimeDays));
  }, [overtimeDays]);

  useEffect(() => {
    localStorage.setItem('overtimeHours', JSON.stringify(overtimeHours));
  }, [overtimeHours]);

  useEffect(() => {
    localStorage.setItem('holidayDays', JSON.stringify(holidayDays));
  }, [holidayDays]);

  const saveOvertimeHours = (month: number, day: number, hours: number) => {
    setOvertimeDays(prev => {
      const currentDays = prev[month] || [];
      if (!currentDays.includes(day)) {
        return { ...prev, [month]: [...currentDays, day] };
      }
      return prev;
    });
    setOvertimeHours(prev => {
      const monthHours = prev[month] || {};
      return {
        ...prev,
        [month]: {
          ...monthHours,
          [day]: hours
        }
      };
    });
    setAbsentDays(prev => {
      const currentDays = prev[month] || [];
      return { ...prev, [month]: currentDays.filter(d => d !== day) };
    });
    setHolidayDays(prev => {
      const currentDays = prev[month] || [];
      return { ...prev, [month]: currentDays.filter(d => d !== day) };
    });
    setOvertimeModalData(null);
  };

  const removeOvertimeHours = (month: number, day: number) => {
    setOvertimeDays(prev => {
      const currentDays = prev[month] || [];
      return { ...prev, [month]: currentDays.filter(d => d !== day) };
    });
    setOvertimeHours(prev => {
      const monthHours = { ...(prev[month] || {}) };
      delete monthHours[day];
      return {
        ...prev,
        [month]: monthHours
      };
    });
    setOvertimeModalData(null);
  };

  useEffect(() => {
    if (selectedMonth || showStats || showMonthStats) {
      document.body.style.overflow = 'hidden';
      document.body.style.height = '100vh';
    } else {
      document.body.style.overflow = 'auto';
      document.body.style.height = 'auto';
      setIsVacationMode(false); // Reset mode when going back to year view
      setIsAbsentMode(false);   // Reset mode when going back to year view
      setIsOvertimeMode(false); // Reset mode when going back to year view
      setIsHolidayMode(false);  // Reset mode when going back to year view
    }
    return () => {
      document.body.style.overflow = 'auto';
      document.body.style.height = 'auto';
    };
  }, [selectedMonth, showStats, showMonthStats]);

  const toggleVacationDay = (month: number, day: number) => {
    if (!isVacationMode && !isAbsentMode && !isOvertimeMode && !isHolidayMode) return;
    
    const isPresent = (vacationDays[month] || []).includes(day);
    const isAbsent = (absentDays[month] || []).includes(day);
    const isOvertime = (overtimeDays[month] || []).includes(day);
    
    const monthObj = monthsData.find(m => m.monthNumber === month);
    const startOffset = monthObj ? monthObj.startOffset : 0;
    const dayOfWeek = (startOffset + day - 1) % 7;
    const isHoliday = (holidayDays[month] || []).includes(day);
    const isWeeklyOff = weeklyOffDays.includes(dayOfWeek);

    if (isVacationMode) {
      if (isAbsent || isHoliday) return;
      const isCurrentlyPresent = (vacationDays[month] || []).includes(day);
      const isCurrentlyHalfPresent = (halfVacationDays[month] || []).includes(day);

      if (isCurrentlyPresent && isCurrentlyHalfPresent) {
        // 3rd tap: remove selection completely
        setVacationDays(prev => {
          const current = prev[month] || [];
          return { ...prev, [month]: current.filter(d => d !== day) };
        });
        setHalfVacationDays(prev => {
          const current = prev[month] || [];
          return { ...prev, [month]: current.filter(d => d !== day) };
        });
      } else if (isCurrentlyPresent) {
        // 2nd tap: half-selected (Half Day Present)
        setHalfVacationDays(prev => {
          const current = prev[month] || [];
          if (!current.includes(day)) {
            return { ...prev, [month]: [...current, day] };
          }
          return prev;
        });
      } else {
        // 1st tap: select the full date with full blue color (Present full day)
        setVacationDays(prev => {
          const current = prev[month] || [];
          if (!current.includes(day)) {
            return { ...prev, [month]: [...current, day] };
          }
          return prev;
        });
        setHalfVacationDays(prev => {
          const current = prev[month] || [];
          return { ...prev, [month]: current.filter(d => d !== day) };
        });
        // Remove from absent list
        setAbsentDays(prev => {
          const current = prev[month] || [];
          return { ...prev, [month]: current.filter(d => d !== day) };
        });
        // Remove from holidays
        setHolidayDays(prev => {
          const current = prev[month] || [];
          return { ...prev, [month]: current.filter(d => d !== day) };
        });
      }
    } else if (isAbsentMode) {
      if (isPresent || isOvertime || isHoliday) return;
      setAbsentDays(prev => {
        const currentDays = prev[month] || [];
        if (currentDays.includes(day)) {
          return { ...prev, [month]: currentDays.filter(d => d !== day) };
        } else {
          return { ...prev, [month]: [...currentDays, day] };
        }
      });
      // Remove from present lists
      setVacationDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      setHalfVacationDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      // Remove from overtime list
      setOvertimeDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      // Remove overtime hours as well to keep state perfectly clean
      setOvertimeHours(prev => {
        const monthHours = { ...(prev[month] || {}) };
        delete monthHours[day];
        return { ...prev, [month]: monthHours };
      });
      // Remove from holidays
      setHolidayDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
    } else if (isOvertimeMode) {
      const existingHours = overtimeHours[month]?.[day] || 1;
      setOvertimeInputValue(String(existingHours));
      setOvertimeModalData({ month, day });
    } else if (isHolidayMode) {
      if (isPresent || isAbsent || isOvertime) return;
      setHolidayDays(prev => {
        const currentDays = prev[month] || [];
        if (currentDays.includes(day)) {
          return { ...prev, [month]: currentDays.filter(d => d !== day) };
        } else {
          return { ...prev, [month]: [...currentDays, day] };
        }
      });
      // Remove from present lists
      setVacationDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      setHalfVacationDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      // Remove from absent list
      setAbsentDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      // Remove from overtime list
      setOvertimeDays(prev => {
        const currentDays = prev[month] || [];
        return { ...prev, [month]: currentDays.filter(d => d !== day) };
      });
      setOvertimeHours(prev => {
        const monthHours = { ...(prev[month] || {}) };
        delete monthHours[day];
        return { ...prev, [month]: monthHours };
      });
    }
  };

  const handleToggleWeeklyOff = (dayOfWeekIdx: number) => {
    setWeeklyOffDays(prev => {
      if (prev.includes(dayOfWeekIdx)) {
        return prev.filter(d => d !== dayOfWeekIdx);
      } else {
        return [...prev, dayOfWeekIdx];
      }
    });
  };

  const handleMonthClick = (monthNumber: number) => {
    setSelectedMonth(monthNumber);
  };

  const activeMonthData = selectedMonth 
    ? monthsData.find(m => m.monthNumber === selectedMonth) 
    : null;

  const totalVacationDays = Object.keys(vacationDays).reduce((acc, monthStr) => {
    const month = parseInt(monthStr);
    const days = vacationDays[month] || [];
    const hDays = halfVacationDays[month] || [];
    const monthTotal = days.reduce((sum, d) => sum + (hDays.includes(d) ? 0.5 : 1), 0);
    return acc + monthTotal;
  }, 0);
  const [showVacationCount, setShowVacationCount] = useState(false);

  useEffect(() => {
    if (showVacationCount) {
      const timer = setTimeout(() => setShowVacationCount(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showVacationCount]);

  return (
    <div className={`w-full ${selectedMonth || showStats || showMonthStats ? 'h-screen overflow-hidden pb-4' : 'min-h-screen pb-12'} flex flex-col items-center pt-2 md:pt-4 px-2 bg-yellow-50/50 text-slate-900`}>
      <header className={`w-full max-w-7xl flex items-center gap-2 px-6 py-3 bg-yellow-400 rounded-2xl shadow-sm border border-yellow-500/20 ${(selectedMonth || showStats || showMonthStats) ? 'mt-2 mb-4' : 'mt-4 mb-8'}`} id="app-header">
        {(selectedMonth || showStats || showMonthStats) ? (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowSettingsModal(true)}
              className="p-2 text-yellow-950/70 hover:text-yellow-950 hover:bg-yellow-500/40 rounded-full transition-all duration-200 cursor-pointer"
              id="settings-button-month"
              aria-label="Settings"
            >
              <Settings size={22} strokeWidth={2} />
            </button>
            <button 
              onClick={() => {
                if (showMonthStats) {
                  setShowMonthStats(false);
                } else {
                  setSelectedMonth(null);
                  setShowStats(false);
                }
              }}
              className="p-2 text-yellow-950/70 hover:text-yellow-950 hover:bg-yellow-500/40 rounded-full transition-all duration-200 cursor-pointer flex items-center gap-1"
              id="back-button"
            >
              <ChevronLeft size={22} strokeWidth={2} />
              <span className="hidden sm:inline text-sm font-medium">Back</span>
            </button>
          </div>
        ) : (
          <button 
            onClick={() => setShowSettingsModal(true)}
            className="p-2 text-yellow-950/70 hover:text-yellow-950 hover:bg-yellow-500/40 rounded-full transition-all duration-200 cursor-pointer"
            id="settings-button"
            aria-label="Settings"
          >
            <Settings size={22} strokeWidth={2} />
          </button>
        )}
        
        <div className="flex flex-col">
          <h1 className="text-xl font-semibold tracking-tight text-yellow-950 leading-none">
            {showMonthStats ? `${activeMonthData?.monthName} Analytics` : showStats ? 'Details' : selectedMonth ? `${activeMonthData?.monthName} 2026` : 'Smart Attendance'}
          </h1>
          {(selectedMonth || showStats || showMonthStats) && (
            <span className="text-[10px] font-mono text-yellow-900/60 uppercase tracking-widest mt-1">
              {showMonthStats ? 'Monthly Stats Detail' : showStats ? 'Statistical Insights' : 'Monthly Detailed View'}
            </span>
          )}
        </div>

        <div className="flex items-center gap-4 ml-auto">
          <AnimatePresence>
            {showVacationCount && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.8 }}
                className="bg-sky-500 text-white px-3 py-1 rounded-full text-[10px] font-bold shadow-lg"
              >
                {totalVacationDays} {totalVacationDays === 1 ? 'Day' : 'Days'}
              </motion.div>
            )}
          </AnimatePresence>
          <div className="flex items-end gap-2">
            <AttendanceMiniChart onClick={() => {
              if (selectedMonth) {
                setShowMonthStats(true);
              } else {
                setShowStats(true);
                setSelectedMonth(null);
              }
            }} />
          </div>
        </div>
      </header>

      <div className={`w-full max-w-7xl px-1 sm:px-4 flex-1 pb-4 ${selectedMonth || showStats || showMonthStats ? 'overflow-hidden flex flex-col justify-center' : ''}`}>
        <AnimatePresence mode="wait">
          {showMonthStats && activeMonthData ? (
            <motion.div
              key="month-stats"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col items-center overflow-y-auto max-h-full w-full"
            >
              <MonthStatsPage
                monthNumber={selectedMonth!}
                monthName={activeMonthData.monthName}
                vacationDays={vacationDays}
                halfVacationDays={halfVacationDays}
                absentDays={absentDays}
                overtimeDays={overtimeDays}
                overtimeHours={overtimeHours}
                holidayDays={holidayDays}
                weeklyOffDays={weeklyOffDays}
              />
            </motion.div>
          ) : showStats ? (
            <motion.div
              key="stats"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col items-center overflow-y-auto max-h-full"
            >
              <StatsPage 
                vacationDays={vacationDays} 
                halfVacationDays={halfVacationDays} 
                absentDays={absentDays} 
                overtimeDays={overtimeDays} 
                overtimeHours={overtimeHours} 
              />
            </motion.div>
          ) : selectedMonth && activeMonthData ? (
            <motion.div
              key="detail"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col items-center w-full h-full justify-center overflow-hidden"
            >
              <div className="w-full max-w-3xl flex flex-col justify-center">
                <MonthCalendar 
                  {...activeMonthData}
                  holidays={holidayDays[selectedMonth] || []}
                  weeklyOffDays={weeklyOffDays}
                  isDetailed
                  today={selectedMonth === 5 ? 19 : undefined} // Mocking today if in current month
                  isVacationMode={isVacationMode}
                  isAbsentMode={isAbsentMode}
                  isOvertimeMode={isOvertimeMode}
                  isHolidayMode={isHolidayMode}
                  onToggleVacationMode={() => {
                    setIsVacationMode(!isVacationMode);
                    setIsAbsentMode(false);
                    setIsOvertimeMode(false);
                    setIsHolidayMode(false);
                  }}
                  onToggleAbsentMode={() => {
                    setIsAbsentMode(!isAbsentMode);
                    setIsVacationMode(false);
                    setIsOvertimeMode(false);
                    setIsHolidayMode(false);
                  }}
                  onToggleOvertimeMode={() => {
                    setIsOvertimeMode(!isOvertimeMode);
                    setIsVacationMode(false);
                    setIsAbsentMode(false);
                    setIsHolidayMode(false);
                  }}
                  onToggleHolidayMode={() => {
                    setIsHolidayMode(!isHolidayMode);
                    setIsVacationMode(false);
                    setIsAbsentMode(false);
                    setIsOvertimeMode(false);
                  }}
                  onDateClick={(day) => toggleVacationDay(selectedMonth, day)}
                  selectedDays={vacationDays[selectedMonth] || []}
                  halfDays={halfVacationDays[selectedMonth] || []}
                  absentDays={absentDays[selectedMonth] || []}
                  overtimeDays={overtimeDays[selectedMonth] || []}
                  monthOvertimeHours={overtimeHours[selectedMonth] || {}}
                />
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="grid"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-2 lg:grid-cols-3 gap-2 md:gap-4 justify-items-center"
              id="calendar-container"
            >
                {monthsData.map((month) => (
                  <div 
                    key={month.monthNumber} 
                    onClick={() => handleMonthClick(month.monthNumber)}
                    className="w-full h-full"
                  >
                    <MonthCalendar 
                      {...month}
                      holidays={holidayDays[month.monthNumber] || []}
                      weeklyOffDays={weeklyOffDays}
                      today={month.monthNumber === 5 ? 19 : undefined}
                      selectedDays={vacationDays[month.monthNumber] || []}
                      halfDays={halfVacationDays[month.monthNumber] || []}
                      absentDays={absentDays[month.monthNumber] || []}
                      overtimeDays={overtimeDays[month.monthNumber] || []}
                      monthOvertimeHours={overtimeHours[month.monthNumber] || {}}
                    />
                  </div>
                ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {overtimeModalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOvertimeModalData(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm shadow-inner"
            />
            {/* Modal Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-[24px] p-6 shadow-2xl border border-slate-100 flex flex-col gap-5 z-55 z-50 text-slate-900"
              id="overtime-modal"
            >
              <div className="flex flex-col gap-1.5 pb-2 border-b border-slate-100">
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-purple-600 font-bold">
                  {monthsData.find(m => m.monthNumber === overtimeModalData.month)?.monthName} {overtimeModalData.day}, 2026
                </span>
                <h3 className="text-xl font-bold font-serif italic text-slate-900">
                  Enter Overtime Hours
                </h3>
              </div>

              {/* Quick presets */}
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Quick Presets</span>
                <div className="grid grid-cols-4 gap-2">
                  {[1, 2, 4, 8].map((preset) => (
                    <button
                      key={`preset-${preset}`}
                      type="button"
                      onClick={() => setOvertimeInputValue(String(preset))}
                      className={`py-2 text-xs font-bold font-mono rounded-xl border transition-all cursor-pointer ${
                        overtimeInputValue === String(preset)
                          ? 'bg-purple-600 border-purple-500 text-white shadow-md'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      +{preset}h
                    </button>
                  ))}
                </div>
              </div>

              {/* Direct numeric input */}
              <div className="flex flex-col gap-2">
                <label htmlFor="overtime-hours-input" className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                  Custom Hours
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="overtime-hours-input"
                    type="number"
                    min="0.5"
                    max="24"
                    step="0.5"
                    value={overtimeInputValue}
                    onChange={(e) => setOvertimeInputValue(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-semibold font-mono text-base focus:outline-none focus:ring-2 focus:ring-purple-300"
                  />
                  <span className="text-sm font-semibold text-slate-500 font-mono">hours</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2 mt-2">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const finalHours = parseFloat(overtimeInputValue);
                      if (isNaN(finalHours) || finalHours <= 0) return;
                      saveOvertimeHours(overtimeModalData.month, overtimeModalData.day, finalHours);
                    }}
                    className="flex-1 bg-purple-600 border border-purple-500 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-xl shadow-md cursor-pointer transition-all text-sm text-center"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setOvertimeModalData(null)}
                    className="flex-1 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold py-3 px-4 rounded-xl cursor-pointer transition-all text-sm text-center"
                  >
                    Cancel
                  </button>
                </div>
                {overtimeDays[overtimeModalData.month]?.includes(overtimeModalData.day) && (
                  <button
                    type="button"
                    onClick={() => removeOvertimeHours(overtimeModalData.month, overtimeModalData.day)}
                    className="w-full bg-red-50 border border-red-100 hover:bg-red-100 text-red-600 font-bold py-2 px-4 rounded-xl cursor-pointer transition-all text-xs text-center mt-1"
                  >
                    Remove Overtime Record
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {showSettingsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettingsModal(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm shadow-inner"
            />
            {/* Modal Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-[24px] p-6 shadow-2xl border border-slate-100 flex flex-col gap-5 z-50 text-slate-900"
              id="settings-modal"
            >
              <div className="flex flex-col gap-1.5 pb-2 border-b border-slate-100">
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-yellow-600 font-bold">
                  Global Dashboard Config
                </span>
                <h3 className="text-xl font-bold font-serif italic text-slate-900">
                  Weekly Off Settings
                </h3>
              </div>

              {/* Checkboxes for days of the week */}
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold mb-1">Select Holidays / Off Days</span>
                <div className="flex flex-col gap-2 max-h-[50vh] overflow-y-auto pr-1">
                  {[
                    { label: "Sunday Off", index: 0 },
                    { label: "Monday Off", index: 1 },
                    { label: "Tuesday Off", index: 2 },
                    { label: "Wednesday Off", index: 3 },
                    { label: "Thursday Off", index: 4 },
                    { label: "Friday Off", index: 5 },
                    { label: "Saturday Off", index: 6 },
                  ].map((day) => {
                    const isChecked = weeklyOffDays.includes(day.index);
                    return (
                      <button
                        key={`weekly-off-${day.index}`}
                        type="button"
                        onClick={() => handleToggleWeeklyOff(day.index)}
                        className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border transition-all cursor-pointer w-full text-left select-none ${
                          isChecked
                            ? "bg-yellow-50 border-yellow-300 shadow-sm animate-pulse-once"
                            : "bg-slate-50 border-slate-100 hover:bg-slate-100"
                        }`}
                      >
                        {/* Custom styled checkbox */}
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center border-2 transition-all shrink-0 ${
                            isChecked
                              ? "bg-yellow-500 border-yellow-500 text-yellow-950"
                              : "border-slate-300"
                          }`}
                        >
                          {isChecked && (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="4"
                              className="w-3.5 h-3.5"
                              referrerPolicy="no-referrer"
                            >
                              <polyline points="20 6 9 17 4 12" />
                            </svg>
                          )}
                        </div>
                        <span className={`text-sm font-semibold ${isChecked ? "text-yellow-950" : "text-slate-700"}`}>
                          {day.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => setShowSettingsModal(false)}
                  className="w-full bg-slate-900 border border-slate-800 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-xl shadow-md cursor-pointer transition-all text-sm text-center"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
